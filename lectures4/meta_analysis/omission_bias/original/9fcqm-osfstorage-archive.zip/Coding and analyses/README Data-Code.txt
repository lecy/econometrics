Folder name: Data

Datafile: Omission-Bias-Coding-Sheet-Meta-v6-G.xlsx

RMarkdown: omission-bias-code-v12-G.Rmd
RMarkdown output word file: omission-bias-code-v12-G.docx
RMarkdown output html file: omission-bias-code-v12-G.html

We also attached png files of the plots in the RMD.

