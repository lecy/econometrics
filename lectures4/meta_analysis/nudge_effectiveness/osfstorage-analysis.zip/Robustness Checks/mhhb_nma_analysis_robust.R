############################################################################
### META-ANALYSIS OF CHOICE ARCHITECTURE INTERVENTIONS ROBUSTNESS CHECKS ###
### S. Mertens, M. Herberz, U.J.J. Hahnel, & T. Brosch                   ###
############################################################################

############## PREPARATION ##############
# Load packages. 
library(dplyr); library(ggplot2); library(metafor); library(readr)

# Load data file.
df <- read_csv('mhhb_nma_data_robust.csv')

# Remove any observation that involves work by Brian Wansink.
df <- df %>%
  filter(wansink == 0)

############## DESCRIPTIVE STATISTICS ##############
# Number of publications and effect sizes.
k_publications <- length(unique(df$publication_id))
k_publications

k_observations <- length(unique(df$es_id))
k_observations

# Number and range of subjects across all studies.
n_total <- df %>%
  group_by(study_id) %>%
  slice(1) %>%
  ungroup() %>%
  summarize(n_total = sum(n_study))
View(n_total)

n_range <- range(df$n_study)
n_range

# Distribution of effect sizes across choice architecture categories.
table(df$intervention_category)

# Number of subjects across choice architecture categories.
n_category <- df %>%
  group_by(study_id) %>%
  slice(1) %>%
  ungroup() %>%
  group_by(intervention_category) %>%
  summarize(n_total = sum(n_study))
View(n_category)

# Distribution of effect sizes across choice architecture techniques.
table(df$intervention_technique)

# Number of subjects across choice architecture techniques.
n_technique <- df %>%
  group_by(study_id) %>%
  slice(1) %>%
  ungroup() %>%
  group_by(intervention_technique) %>%
  summarize(n_total = sum(n_study))
View(n_technique)

# Distribution of effect sizes across behavioral domains.
table(df$domain)

# Number of subjects across behavioral domains.
n_domain <- df %>%
  group_by(study_id) %>%
  slice(1) %>%
  ungroup() %>%
  group_by(domain) %>%
  summarize(n_total = sum(n_study))
View(n_domain)

# Distribution of effect sizes across behavioral domains and choice architecture categories.
table(df$domain, df$intervention_category)

# Number of subjects across behavioral domains and choice architecture categories.
n_domain_category <- df %>%
  group_by(study_id) %>%
  slice(1) %>%
  ungroup() %>%
  group_by(domain, intervention_category) %>%
  summarize(n_total = sum(n_study))
View(n_domain_category)

# Distribution of effect sizes across geographical locations.
table(df$location)

# Number of subjects across geographical locations.
n_location <- df %>%
  group_by(study_id) %>%
  slice(1) %>%
  ungroup() %>%
  group_by(location) %>%
  summarize(n_total = sum(n_study))
View(n_location)

# Distribution of effect sizes across geographical location and choice architecture categories.
table(df$location, df$intervention_category)

# Distribution of studies across target populations.
table(df$population)

# Number of subjects across target populations.
n_population <- df %>%
  group_by(study_id) %>%
  slice(1) %>%
  ungroup() %>%
  group_by(population) %>%
  summarize(n_total = sum(n_study))
View(n_population)

# Distribution of effect sizes across target population and choice architecture categories.
table(df$population, df$intervention_category)

# Distribution of studies across types of experiment.
table(df$type_experiment)

# Number of subjects across types of experiment.
n_experiment <- df %>%
  group_by(study_id) %>%
  slice(1) %>%
  ungroup() %>%
  group_by(type_experiment) %>%
  summarize(n_total = sum(n_study))
View(n_experiment)

# Distribution of effect sizes across types of experiment and choice architecture categories.
table(df$type_experiment, df$intervention_category)

# Range of publication years.
range(df$year)

############## PRIMARY META-ANALYSIS ##############
# Primary effect size of choice architecture interventions. 
primary <- metafor::rma.mv(cohens_d, variance_d, data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE, slab = reference)
summary(primary)

# Robust test and confidence intervals accounting for dependence in sampling errors (i.e., clusters within studies due to overlap of participants)
primary_robust <- robust(primary, cluster = df$study_id)
summary(primary_robust)

# Prediction interval for primary effect size of choice architecture interventions.
predict_primary <- predict(primary_robust)
predict_primary

############## HETEROGENEITY ##############
# Statistical significance of within-study variance.
variance_level2 <- metafor::rma.mv(cohens_d, variance_d, data = df, random = ~ 1 | publication_id/es_id, sigma2 = c(0, NA), tdist = TRUE)
anova(primary, variance_level2)

# Statistical significance of between-study variance.
variance_level3 <- metafor::rma.mv(cohens_d, variance_d, data = df, random = ~ 1 | publication_id/es_id, sigma2 = c(NA, 0), tdist = TRUE)
anova(primary, variance_level3)

# Total heterogeneity across studies (Tau squared).
sum(primary_robust$sigma2)

# Ratio of true to total variance across studies (I squared).
w <- diag(1 / df$variance_d)
x <- model.matrix(primary_robust)
p <- w - w %*% x %*% solve(t(x) %*% w %*% x) %*% t(x) %*% w
i_square <- 100 * sum(primary_robust$sigma2) / (sum(primary_robust$sigma2) + (primary_robust$k-primary_robust$p)/sum(diag(p)))
i_square

# Distribution of I squared within and between studies.
distribution_i_square <- 100 * primary_robust$sigma2 / (sum(primary_robust$sigma2) + (primary_robust$k-primary_robust$p)/sum(diag(p)))
distribution_i_square # [between studies (i.e., level 3)] [within studies (i.e., level 2)]

############## SENSITIVITY ANALYSIS ##############
# Standardized residuals.
resid <- rstandard(primary, progbar = TRUE, reestimate = TRUE)
outliers_resid <-  resid %>%
  subset(resid$z > 3 | resid$z < -3) # determine outliers
outliers_resid

# Cook's distance.
cooks_distance <- cooks.distance.rma.mv(primary, progbar = TRUE, reestimate = TRUE)
outliers_cooks <- cooks_distance %>%
  subset(cooks_distance > 4 / (424 - 1 - 1)) # determine influence
outliers_cooks

# Plot of standardized residuals across Cook's distance.
plot(cooks_distance, resid$z, xlim = c(0, 0.2), ylim = c(-7, 7))
text(cooks_distance, resid$z, labels = df$es_id, pos = 2)
abline(h = 3)
abline(h = -3)
abline(v = 4/(424-1-1))

# Primary meta-analysis w/out influential outliers.
primary_sens <- metafor::rma.mv(cohens_d, variance_d, data = df, subset = c(-1, -3, -6), random = ~ 1 | publication_id/es_id, tdist = TRUE, slab = reference)
summary(primary_sens)

# Robust test and confidence intervals accounting for dependence in sampling errors.
primary_sens_robust <- robust(primary_sens, cluster = df$study_id)
summary(primary_sens_robust)

# Leave-one-out analysis at effect size level.
df_loo <- matrix(0, ncol = 12, nrow = nrow(df))
df_loo <- data.frame(df_loo)
colnames(df_loo) <- c("estimate", "se", "tval", "pval", "ci.lb", "ci.ub", "sigma.total", "sigma2.1",
                      "sigma2.2", "i2total", "i2between", "i2within")
for(i in 1:nrow(df))
{
  df1 <- df[c(-i),]
  loo <- metafor::rma.mv(cohens_d, variance_d, data = df1, random = ~ 1 | publication_id/es_id, tdist = TRUE)
  loo_robust <- robust(loo, cluster = df1$study_id, adjust = TRUE)
  df_loo[i, 1] <- loo_robust$b
  df_loo[i, 2] <- loo_robust$se
  df_loo[i, 4] <- loo_robust$pval
  df_loo[i, 5] <- loo_robust$ci.lb
  df_loo[i, 6] <- loo_robust$ci.ub
  df_loo[i, 7] <- loo_robust$sigma2[1] + loo_robust$sigma2[2]
  df_loo[i, 8] <- loo_robust$sigma2[1]
  df_loo[i, 9] <- loo_robust$sigma2[2]
  w <- diag(1/df1$variance_d)
  x <- model.matrix(loo_robust)
  p <- w - w %*% x %*% solve(t(x) %*% w %*% x) %*% t(x) %*% w
  i2.ml <- 100 * loo_robust$sigma2 / (sum(loo_robust$sigma2) + (loo_robust$k - loo_robust$p)/sum(diag(p)))
  df_loo[i, 10] <- i2.ml[1] + i2.ml[2]
  df_loo[i, 11] <- i2.ml[1]
  df_loo[i, 12] <- i2.ml[2]
}
range(df_loo$estimate)
range(df_loo$pval)

# Leave-one-out analysis at publication size level.
df_loopub <- matrix(0, ncol = 13, nrow = 203)
df_loopub <- data.frame(df_loopub)
colnames(df_loopub) <- c("numES", "estimate", "se", "tval", "pval", "ci.lb", "ci.ub", "sigma.total",
                       "sigma2.1", "sigma2.2", "i2total", "i2between", "i2within")

for(i in 1:214)
{
  df2 <- subset(df, publication_id != i)
  loopub <- metafor::rma.mv(cohens_d, variance_d, data = df2, random = ~ 1 | publication_id/es_id, tdist = TRUE)
  loopub_robust <- robust(loopub, cluster = df2$study_id, adjust = TRUE)
  df_loopub[i, 1] <- nrow(df) - nrow(df2)
  df_loopub[i, 2] <- loopub_robust$b
  df_loopub[i, 3] <- loopub_robust$se
  df_loopub[i, 5] <- loopub_robust$pval
  df_loopub[i, 6] <- loopub_robust$ci.lb
  df_loopub[i, 7] <- loopub_robust$ci.ub
  df_loopub[i, 8] <- loopub_robust$sigma2[1] + loopub_robust$sigma2[2]
  df_loopub[i, 9] <- loopub_robust$sigma2[1]
  df_loopub[i, 10] <- loopub_robust$sigma2[2]
  w <- diag(1/df2$variance_d)
  x <- model.matrix(loopub_robust)
  p <- w - w %*% x %*% solve(t(x) %*% w %*% x) %*% t(x) %*% w
  i2.ml <- 100 * loopub_robust$sigma2 / (sum(loopub_robust$sigma2) + (loopub_robust$k - loopub_robust$p)/sum(diag(p)))
  df_loopub[i,11] <- i2.ml[1]+i2.ml[2] 
  df_loopub[i,12] <- i2.ml[1]
  df_loopub[i,13] <- i2.ml[2]
}
range(df_loopub$estimate)
range(df_loopub$pval)

############## FOREST PLOT ##############
# Forest plot of primary effect size.
par(mar = c(4, 4, 1, 2))
forest(primary_robust, xlim = c(-2, 6), slab = NA, at = c(-1, 0, 1, 2, 3, 4, 5), annotate = FALSE, efac = 0, pch = 19, col = 'gray40',
       psize = 2, cex.lab = 1, cex.axis = 1, lty = c('solid','blank'))
points(sort(df$cohens_d), 1:424, pch = 19, cex = 0.5)
addpoly(primary_robust, mlab="Model estimate: d = .40*** [0.35, 0.45]", annotate = FALSE, cex = 0.5, row = -7)
addpoly.default(x = predict_primary$pred, ci.lb = predict_primary$pi.lb, ci.ub = predict_primary$pi.ub, rows = -15, mlab = "Prediction interval", cex = 0.5)

############## PUBLICATION BIAS ##############
# Funnel plot of primary effect size.
funnel(primary, ylim = c(0, 0.60), xlab = "Effect size (Cohen's d)")

# Egger's test of asymmetry.
primary_eggers <- metafor::rma.mv(cohens_d, variance_d, mod = ~ sqrt(variance_d), random = ~ 1 | publication_id/es_id, data = df)
primary_eggers_robust <- robust(primary_eggers, cluster = df$study_id, adjust = TRUE)
summary(primary_eggers_robust)

# Sensitivity analysis for publication bias.
tab <- data.frame(
  steps = c(0.005, 0.01, 0.05, 0.10, 0.25, 0.35, 0.50, 0.65, 0.75, 0.90, 0.95, 0.99, 0.995, 1),
  delta.mod.1 = c(1, 0.99, 0.95, 0.80, 0.75, 0.65, 0.60, 0.55, 0.50, 0.50, 0.50, 0.50, 0.50, 0.50), 
  delta.sev.1 = c(1, 0.99, 0.90, 0.75, 0.60, 0.50, 0.40, 0.35, 0.30, 0.25, 0.10, 0.10, 0.10, 0.10))

# Simplified random-effects model estimating overall effect size of choice architecture interventions.
primary_rma <- rma.uni(cohens_d, variance_d, data = df)
summary(primary_rma)

# Moderate one-tailed selection bias scenario.
primary_mod1 <- metafor::selmodel(primary_rma, type = 'stepfun', alternative = 'greater', delta = tab$delta.mod.1, steps = tab$steps)
summary(primary_mod1)

# Severe one-tailed selection bias scenario.
primary_sev1 <- metafor::selmodel(primary_rma, type = 'stepfun', alternative = 'greater', delta = tab$delta.sev.1, steps = tab$steps)
summary(primary_sev1)

############## MODERATOR ANALYSIS CHOICE ARCHITECTURE CATEGORY ##############
# Effect size estimates for each choice architecture category.
category <- metafor::rma.mv(cohens_d, variance_d, mods = ~ factor(intervention_category) + scale(year) - 1, data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
category_robust <- robust(category, cluster = df$study_id, adjust=TRUE)
summary(category_robust)

# Comparison of effect sizes across choice architecture categories (reference category: decision information). 
information <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'information') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
information_robust <- robust(information, cluster = df$study_id)
summary(information_robust)

# Comparison of effect sizes across choice architecture categories (reference category: decision structure). 
structure <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'structure') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
structure_robust <- robust(structure, cluster = df$study_id)
summary(structure_robust)

# Comparison of effect sizes across choice architecture categories (reference category: decision assistance). 
assistance <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'assistance') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
assistance_robust <- robust(assistance, cluster = df$study_id)
summary(assistance_robust)

# Ratio of true to total heterogeneity across studies (I squared).
w <- diag(1 / df$variance_d)
x <- model.matrix(information_robust)
p <- w - w %*% x %*% solve(t(x) %*% w %*% x) %*% t(x) %*% w
i_square <- 100 * sum(information_robust$sigma2) / (sum(information_robust$sigma2) + (information_robust$k-information_robust$p)/sum(diag(p)))
i_square

# Distribution of I squared within and between studies.
distribution_i_square <- 100 * information_robust$sigma2 / (sum(information_robust$sigma2) + (information_robust$k-information_robust$p)/sum(diag(p)))
distribution_i_square # [between studies (i.e., level 3)] [within studies (i.e., level 2)]

############## MODERATOR ANALYSIS CHOICE ARCHITECTURE TECHNIQUE ##############
# Effect size estimates for each choice architecture technique.
technique <- metafor::rma.mv(cohens_d, variance_d, mods = ~ factor(intervention_technique) + scale(year) - 1, data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
technique_robust <- robust(technique, cluster = df$study_id, adjust=TRUE)
summary(technique_robust)

# Comparison of effect sizes across choice architecture techniques (reference category: translation). 
translation <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_technique), ref = 'translation') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
translation_robust <- robust(translation, cluster = df$study_id, adjust=TRUE)
summary(translation_robust)

# Comparison of effect sizes across choice architecture techniques (reference category: visibility). 
visibility <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_technique), ref = 'visibility') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
visibility_robust <- robust(visibility, cluster = df$study_id, adjust=TRUE)
summary(visibility_robust)

# Comparison of effect sizes across choice architecture techniques (reference category: social reference). 
social_reference <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_technique), ref = 'social_reference') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
social_reference_robust <- robust(social_reference, cluster = df$study_id, adjust=TRUE)
summary(social_reference_robust)

# Comparison of effect sizes across choice architecture techniques (reference category: default). 
default <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_technique), ref = 'default') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
default_robust <- robust(default, cluster = df$study_id, adjust=TRUE)
summary(default_robust)

# Comparison of effect sizes across choice architecture techniques (reference category: effort). 
effort <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_technique), ref = 'effort') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
effort_robust <- robust(effort, cluster = df$study_id, adjust=TRUE)
summary(effort_robust)

# Comparison of effect sizes across choice architecture techniques (reference category: composition). 
composition <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_technique), ref = 'composition') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
composition_robust <- robust(composition, cluster = df$study_id, adjust=TRUE)
summary(composition_robust)

# Comparison of effect sizes across choice architecture techniques (reference category: consequence). 
consequence <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_technique), ref = 'consequence') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
consequence_robust <- robust(consequence, cluster = df$study_id, adjust=TRUE)
summary(consequence_robust)

# Comparison of effect sizes across choice architecture techniques (reference category: reminder). 
reminder <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_technique), ref = 'reminder') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
reminder_robust <- robust(reminder, cluster = df$study_id, adjust=TRUE)
summary(reminder_robust)

# Comparison of effect sizes across choice architecture techniques (reference category: commitment). 
commitment <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_technique), ref = 'commitment') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
commitment_robust <- robust(commitment, cluster = df$study_id, adjust=TRUE)
summary(commitment_robust)

############## MODERATOR ANALYSIS BEHAVIORAL DOMAINS ##############
# Effect size estimates for each behavioral domain.
domain <- metafor::rma.mv(cohens_d, variance_d, mods = ~ factor(domain) + scale(year) - 1, data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
domain_robust <- robust(domain, cluster = df$study_id, adjust=TRUE)
summary(domain_robust)

# Comparison of effect sizes across behavioral domains (reference category: health). 
health <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(domain), ref = 'health') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
health_robust <- robust(health, cluster = df$study_id, adjust=TRUE)
summary(health_robust)

# Comparison of effect sizes across behavioral domains (reference category: food). 
food <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(domain), ref = 'food') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
food_robust <- robust(food, cluster = df$study_id, adjust=TRUE)
summary(food_robust)

# Comparison of effect sizes across behavioral domains (reference category: environment). 
environment <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(domain), ref = 'environment') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
environment_robust <- robust(environment, cluster = df$study_id, adjust=TRUE)
summary(environment_robust)

# Comparison of effect sizes across behavioral domains (reference category: finance). 
finance <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(domain), ref = 'finance') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
finance_robust <- robust(finance, cluster = df$study_id, adjust=TRUE)
summary(finance_robust)

# Comparison of effect sizes across behavioral domains (reference category: pro-social behavior). 
prosocial <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(domain), ref = 'pro-social') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
prosocial_robust <- robust(prosocial, cluster = df$study_id, adjust=TRUE)
summary(prosocial_robust)

# Comparison of effect sizes across behavioral domains (reference category: other behavior). 
other <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(domain), ref = 'other') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
other_robust <- robust(other, cluster = df$study_id, adjust=TRUE)
summary(other_robust)

# Ratio of true to total heterogeneity across studies (I squared).
w <- diag(1 / df$variance_d)
x <- model.matrix(health_robust)
p <- w - w %*% x %*% solve(t(x) %*% w %*% x) %*% t(x) %*% w
i_square <- 100 * sum(health_robust$sigma2) / (sum(health_robust$sigma2) + (health_robust$k-health_robust$p)/sum(diag(p)))
i_square

# Distribution of I squared within and between studies.
distribution_i_square <- 100 * health_robust$sigma2 / (sum(health_robust$sigma2) + (health_robust$k-health_robust$p)/sum(diag(p)))
distribution_i_square # [between studies (i.e., level 3)] [within studies (i.e., level 2)]

############## MODERATOR ANALYSIS CHOICE ARCHITECTURE CATEGORIES ACROSS BEHAVIORAL DOMAINS ##############
### HEALTH
# Comparison of effect sizes of choice architecture categories in health domain (reference category: decision information). 
health_information <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'information') * relevel(factor(domain), ref = 'health') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
health_information_robust <- robust(health_information, cluster = df$study_id)
summary(health_information_robust)

# Comparison of effect sizes of choice architecture categories in health domain (reference category: decision structure). 
health_structure <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'structure') * relevel(factor(domain), ref = 'health') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
health_structure_robust <- robust(health_structure, cluster = df$study_id)
summary(health_structure_robust)

# Comparison of effect sizes of choice architecture categories in health domain (reference category: decision assistance). 
health_assistance <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'assistance') * relevel(factor(domain), ref = 'health') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
health_assistance_robust <- robust(health_assistance, cluster = df$study_id)
summary(health_assistance_robust)

### FOOD
# Comparison of effect sizes of choice architecture categories in food domain (reference category: decision information). 
food_information <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'information') * relevel(factor(domain), ref = 'food') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
food_information_robust <- robust(food_information, cluster = df$study_id)
summary(food_information_robust)

# Comparison of effect sizes of choice architecture categories in food domain (reference category: decision structure). 
food_structure <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'structure') * relevel(factor(domain), ref = 'food') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
food_structure_robust <- robust(food_structure, cluster = df$study_id)
summary(food_structure_robust)

# Comparison of effect sizes of choice architecture categories in food domain (reference category: decision assistance). 
food_assistance <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'assistance') * relevel(factor(domain), ref = 'food') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
food_assistance_robust <- robust(food_assistance, cluster = df$study_id)
summary(food_assistance_robust)

### ENVIRONMENT
# Comparison of effect sizes of choice architecture categories in environment domain (reference category: decision information). 
environment_information <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'information') * relevel(factor(domain), ref = 'environment') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
environment_information_robust <- robust(environment_information, cluster = df$study_id)
summary(environment_information_robust)

# Comparison of effect sizes of choice architecture categories in environment domain (reference category: decision structure). 
environment_structure <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'structure') * relevel(factor(domain), ref = 'environment') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
environment_structure_robust <- robust(environment_structure, cluster = df$study_id)
summary(environment_structure_robust)

# Comparison of effect sizes of choice architecture categories in environment domain (reference category: decision assistance). 
environment_assistance <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'assistance') * relevel(factor(domain), ref = 'environment') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
environment_assistance_robust <- robust(environment_assistance, cluster = df$study_id)
summary(environment_assistance_robust)

### FINANCE
# Comparison of effect sizes of choice architecture categories in finance domain (reference category: decision information). 
finance_information <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'information') * relevel(factor(domain), ref = 'finance') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
finance_information_robust <- robust(finance_information, cluster = df$study_id)
summary(finance_information_robust)

# Comparison of effect sizes of choice architecture categories in finance domain (reference category: decision structure). 
finance_structure <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'structure') * relevel(factor(domain), ref = 'finance') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
finance_structure_robust <- robust(finance_structure, cluster = df$study_id)
summary(finance_structure_robust)

# Comparison of effect sizes of choice architecture categories in finance domain (reference category: decision assistance). 
finance_assistance <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'assistance') * relevel(factor(domain), ref = 'finance') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
finance_assistance_robust <- robust(finance_assistance, cluster = df$study_id)
summary(finance_assistance_robust)

### PRO-SOCIAL BEHAVIOR
# Comparison of effect sizes of choice architecture categories in pro-social behavior domain (reference category: decision information). 
prosocial_information <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'information') * relevel(factor(domain), ref = 'pro-social') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
prosocial_information_robust <- robust(prosocial_information, cluster = df$study_id)
summary(prosocial_information_robust)

# Comparison of effect sizes of choice architecture categories in pro-social behavior domain (reference category: decision structure). 
prosocial_structure <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'structure') * relevel(factor(domain), ref = 'pro-social') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
prosocial_structure_robust <- robust(prosocial_structure, cluster = df$study_id)
summary(prosocial_structure_robust)

# Comparison of effect sizes of choice architecture categories in pro-social behavior domain (reference category: decision assistance). 
prosocial_assistance <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'assistance') * relevel(factor(domain), ref = 'pro-social') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
prosocial_assistance_robust <- robust(prosocial_assistance, cluster = df$study_id)
summary(prosocial_assistance_robust)

### OTHER
# Comparison of effect sizes of choice architecture categories in other behavior domain (reference category: decision information). 
other_information <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'information') * relevel(factor(domain), ref = 'other') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
other_information_robust <- robust(other_information, cluster = df$study_id)
summary(other_information_robust)

# Comparison of effect sizes of choice architecture categories in other behavior domain (reference category: decision structure). 
other_structure <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'structure') * relevel(factor(domain), ref = 'other') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
other_structure_robust <- robust(other_structure, cluster = df$study_id)
summary(other_structure_robust)

# Comparison of effect sizes of choice architecture categories in other behavior domain (reference category: decision assistance). 
other_assistance <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'assistance') * relevel(factor(domain), ref = 'other') + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
other_assistance_robust <- robust(other_assistance, cluster = df$study_id)
summary(other_assistance_robust)

# Ratio of true to total heterogeneity across studies (I squared).
w <- diag(1 / df$variance_d)
x <- model.matrix(health_information_robust)
p <- w - w %*% x %*% solve(t(x) %*% w %*% x) %*% t(x) %*% w
i_square <- 100 * sum(health_information_robust$sigma2) / (sum(health_information_robust$sigma2) + (health_information_robust$k-health_information_robust$p)/sum(diag(p)))
i_square

# Distribution of I squared within and between studies.
distribution_i_square <- 100 * health_information_robust$sigma2 / (sum(health_information_robust$sigma2) + (health_information_robust$k-health_information_robust$p)/sum(diag(p)))
distribution_i_square # [between studies (i.e., level 3)] [within studies (i.e., level 2)]

############## SENSITIVITY ANALYSIS FOOD DOMAIN ##############
# Effect size decision information in food domain. 
food_information_sens <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'information') * relevel(factor(domain), ref = 'food') + scale(year), data = df, subset = c(-1, -2, -3), random = ~ 1 | publication_id/es_id, tdist = TRUE)
food_information_sens_robust <- robust(food_information_sens, cluster = df$study_id)
summary(food_information_sens_robust)

# Effect size decision structure in food domain. 
food_structure_sens <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'structure') * relevel(factor(domain), ref = 'food') + scale(year), data = df, subset = c(-1, -2, -3), random = ~ 1 | publication_id/es_id, tdist = TRUE)
food_structure_sens_robust <- robust(food_structure_sens, cluster = df$study_id)
summary(food_structure_sens_robust)

# Effect size decision assistance in food domain. 
food_assistance_sens <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(intervention_category), ref = 'assistance') * relevel(factor(domain), ref = 'food') + scale(year), data = df, subset = c(-1, -2, -3), random = ~ 1 | publication_id/es_id, tdist = TRUE)
food_assistance_sens_robust <- robust(food_assistance_sens, cluster = df$study_id)
summary(food_assistance_sens_robust)

# Total effect size in food domain. 
food_sens <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(domain), ref = 'food') + scale(year), data = df, subset = c(-1, -2, -3), random = ~ 1 | publication_id/es_id, tdist = TRUE)
food_sens_robust <- robust(food_sens, cluster = df$study_id, adjust=TRUE)
summary(food_sens_robust)

############## MODERATOR ANALYSIS CONTEXTUAL STUDY CHARACTERISTICS ##############
# Effect size estimates of location (reference category: outside of United States).
location_outside <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(location), ref = '0'), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
location_outside_robust <- robust(location_outside, cluster = df$study_id, adjust=TRUE)
summary(location_outside_robust)

# Effect size estimates of location (reference category: inside of United States).
location_inside <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(location), ref = '1'), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
location_inside_robust <- robust(location_inside, cluster = df$study_id, adjust=TRUE)
summary(location_inside_robust)

# Effect size estimates of target population (reference category: children and adolescents).
population_children <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(population), ref = '0'), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
population_children_robust <- robust(population_children, cluster = df$study_id, adjust=TRUE)
summary(population_children_robust)

# Effect size estimates of target population (reference category: adults).
population_adults <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(population), ref = '1'), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
population_adults_robust <- robust(population_adults, cluster = df$study_id, adjust=TRUE)
summary(population_adults_robust)

# Effect size estimates of type of experiment (reference category: conventional lab experiment).
experiment_conventional <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(type_experiment), ref = 'conventional_lab'), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
experiment_conventional_robust <- robust(experiment_conventional, cluster = df$study_id, adjust=TRUE)
summary(experiment_conventional_robust)

# Effect size estimates of type of experiment (reference category: artefactual field experiment).
experiment_artefactual <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(type_experiment), ref = 'artefactual_field'), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
experiment_artefactual_robust <- robust(experiment_artefactual, cluster = df$study_id, adjust=TRUE)
summary(experiment_artefactual_robust)

# Effect size estimates of type of experiment (reference category: framed field experiment).
experiment_framed <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(type_experiment), ref = 'framed_field'), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
experiment_framed_robust <- robust(experiment_framed, cluster = df$study_id, adjust=TRUE)
summary(experiment_framed_robust)

# Effect size estimates of type of experiment (reference category: natural field experiment).
experiment_natural <- metafor::rma.mv(cohens_d, variance_d, mods = ~ relevel(factor(type_experiment), ref = 'natural_field'), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
experiment_natural_robust <- robust(experiment_natural, cluster = df$study_id, adjust=TRUE)
summary(experiment_natural_robust)

# Effect size estimates of year of publication.
year_publication <- metafor::rma.mv(cohens_d, variance_d, mods = ~ scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
year_publication_robust <- robust(year_publication, cluster = df$study_id, adjust=TRUE)
summary(year_publication_robust)

# Effect size estimates of of all contextual study characteristics.
study_characteristics <- metafor::rma.mv(cohens_d, variance_d, mods = ~ factor(type_experiment) + factor(location) + factor(population) + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
study_characteristics_robust <- robust(study_characteristics, cluster = df$study_id, adjust=TRUE)
summary(study_characteristics_robust)

# Ratio of true to total heterogeneity across studies (I squared).
w <- diag(1 / df$variance_d)
x <- model.matrix(study_characteristics_robust)
p <- w - w %*% x %*% solve(t(x) %*% w %*% x) %*% t(x) %*% w
i_square <- 100 * sum(study_characteristics_robust$sigma2) / (sum(study_characteristics_robust$sigma2) + (study_characteristics_robust$k-study_characteristics_robust$p)/sum(diag(p)))
i_square

# Distribution of I squared within and between studies.
distribution_i_square <- 100 * study_characteristics_robust$sigma2 / (sum(study_characteristics_robust$sigma2) + (study_characteristics_robust$k-study_characteristics_robust$p)/sum(diag(p)))
distribution_i_square # [between studies (i.e., level 3)] [within studies (i.e., level 2)]

############## FULL MODERATOR MODEL ##############
moderators <- metafor::rma.mv(cohens_d, variance_d, mods = ~ factor(intervention_category) * factor(domain) + factor(type_experiment) + factor(location) + factor(population) + scale(year), data = df, random = ~ 1 | publication_id/es_id, tdist = TRUE)
moderators_robust <- robust(moderators, cluster = df$study_id)
summary(moderators_robust)

# Ratio of true to total heterogeneity across studies (I squared).
w <- diag(1 / df$variance_d)
x <- model.matrix(moderators_robust)
p <- w - w %*% x %*% solve(t(x) %*% w %*% x) %*% t(x) %*% w
i_square <- 100 * sum(moderators_robust$sigma2) / (sum(moderators_robust$sigma2) + (moderators_robust$k-moderators_robust$p)/sum(diag(p)))
i_square

# Distribution of I squared within and between studies.
distribution_i_square <- 100 * moderators_robust$sigma2 / (sum(moderators_robust$sigma2) + (moderators_robust$k-moderators_robust$p)/sum(diag(p)))
distribution_i_square # [between studies (i.e., level 3)] [within studies (i.e., level 2)]

